/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef USE_TYPE_CAIRO
#define USE_TYPE_CAIRO
#endif
#ifdef USE_TYPE_XFT
#undef USE_TYPE_XFT
#endif

#include "ui_font_ft.c"
