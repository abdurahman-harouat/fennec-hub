/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#include "../ui_sb_view_factory.h"

void ui_sb_view_set_dpr(int dpr) {}
