/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef ___UI_SCROLLBAR_H__
#define ___UI_SCROLLBAR_H__

#include "../ui_scrollbar.h"

void ui_scrollbar_is_moved(ui_scrollbar_t *sb, float pos);

#endif