/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __UI_SIMPLE_SB_VIEW_H__
#define __UI_SIMPLE_SB_VIEW_H__

#include "ui_sb_view.h"

ui_sb_view_t *ui_simple_sb_view_new(int dpr);

ui_sb_view_t *ui_simple_transparent_sb_view_new(int dpr);

#endif
