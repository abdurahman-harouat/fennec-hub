/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#include <pobl/bl_types.h>

void ui_emoji_set_path(const char *path);

void ui_emoji_set_file_format(const char *format);

char *ui_emoji_get_path(u_int32_t code1, u_int32_t code2, int check_exist);

char *ui_emoji_get_file_format(void);
