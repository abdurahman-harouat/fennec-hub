/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

void syswminfo_init(void *window);

int syswminfo_is_thread_safe(void);
