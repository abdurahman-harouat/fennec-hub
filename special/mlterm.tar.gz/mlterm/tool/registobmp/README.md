registobmp is derived from regis.c and nsdl.c of hterm 2.0.
registobmp is available under the GPL, see http://www.gnu.org/licenses/gpl.html
The original README.md is as follows.

hterm
=====

For full details about hterm see: http://41j.com/hterm

HTerm (or hackterm) is a terminal emulator based on SDL and libvterm. It uses it's own bitmap unicode font render library and is capable of displaying basic Regis and inline PNG graphics. HTerm will currently compile on MacOS,Linux and iOS. Windows and Android ports should also be possible. HTerm has been made available under the GPL, see http://www.gnu.org/licenses/gpl.html

