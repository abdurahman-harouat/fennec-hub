/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __MC_SB_VIEW_H__
#define __MC_SB_VIEW_H__

#include <gtk/gtk.h>

GtkWidget *mc_sb_view_config_widget_new(void);

void mc_update_sb_view_name(void);

#endif
