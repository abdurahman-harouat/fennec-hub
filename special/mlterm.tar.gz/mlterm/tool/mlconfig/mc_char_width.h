/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __MC_CHAR_WIDTH_H__
#define __MC_CHAR_WIDTH_H__

#include <gtk/gtk.h>

GtkWidget *mc_char_width_config_widget_new(void);

void mc_update_char_width(void);

#endif
