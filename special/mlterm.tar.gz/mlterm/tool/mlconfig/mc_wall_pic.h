/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __MC_WALL_PIC_H__
#define __MC_WALL_PIC_H__

#include <gtk/gtk.h>

GtkWidget *mc_wall_pic_config_widget_new(void);

void mc_update_wall_pic(void);

void mc_wall_pic_none(void);

#endif
