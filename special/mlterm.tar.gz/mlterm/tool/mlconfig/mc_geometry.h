/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __MC_GEOMETRY_H__
#define __MC_GEOMETRY_H__

#include <gtk/gtk.h>

GtkWidget *mc_geometry_config_widget_new(void);

void mc_update_geometry(void);

#endif
