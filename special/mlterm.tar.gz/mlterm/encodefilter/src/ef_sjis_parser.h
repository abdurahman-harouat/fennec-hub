/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __EF_SJIS_PARSER_H__
#define __EF_SJIS_PARSER_H__

#include "ef_parser.h"

ef_parser_t *ef_sjis_parser_new(void);

ef_parser_t *ef_sjisx0213_parser_new(void);

#endif
