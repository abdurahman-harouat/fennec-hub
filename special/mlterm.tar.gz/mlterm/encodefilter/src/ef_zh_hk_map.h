/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __EF_ZH_HK_MAP_H__
#define __EF_ZH_HK_MAP_H__

#include "ef_char.h"

int ef_map_ucs4_to_zh_hk(ef_char_t *zhhk, ef_char_t *ucs4);

#endif
