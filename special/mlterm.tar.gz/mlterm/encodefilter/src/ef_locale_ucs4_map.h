/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __EF_LOCALE_UCS4_MAP_H__
#define __EF_LOCALE_UCS4_MAP_H__

#include "ef_char.h"

int ef_map_locale_ucs4_to(ef_char_t *non_ucs4, ef_char_t *ucs4);

#endif
