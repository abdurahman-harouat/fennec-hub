/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __EF_BIG5_CONV_H___
#define __EF_BIG5_CONV_H___

#include "ef_conv.h"

ef_conv_t *ef_big5_conv_new(void);

ef_conv_t *ef_big5hkscs_conv_new(void);

#endif
