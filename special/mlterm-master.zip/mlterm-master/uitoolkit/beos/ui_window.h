/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#include "../ui_window.h"

int ui_window_clear_margin_area(ui_window_t *win);
