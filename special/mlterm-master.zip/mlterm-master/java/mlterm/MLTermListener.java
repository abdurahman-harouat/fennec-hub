/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

package mlterm;

public interface MLTermListener {
  public void sizeChanged();

  public void ptyClosed();
}
