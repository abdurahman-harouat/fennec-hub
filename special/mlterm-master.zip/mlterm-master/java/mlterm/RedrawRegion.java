/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

package mlterm;

public class RedrawRegion {
  public String str = null;
  public int start = 0;

  public Style[] styles = null;
}
