/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#include "bl_langinfo.h"

#ifdef USE_BUILTIN_LANGINFO

/* --- global functions --- */

char* __bl_langinfo(nl_item item) { return ""; }

#endif /* USE_BUILTIN_LANGINFO */
