/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __EF_STR_PARSER_H__
#define __EF_STR_PARSER_H__

#include <mef/ef_parser.h>

ef_parser_t *ef_str_parser_get(void);

#endif
