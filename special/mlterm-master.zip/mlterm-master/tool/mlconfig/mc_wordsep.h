/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __MC_WORDSEP_H__
#define __MC_WORDSEP_H__

#include <gtk/gtk.h>

GtkWidget *mc_wordsep_config_widget_new(void);

void mc_update_wordsep(void);

#endif
