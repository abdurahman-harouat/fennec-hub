/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __MC_OPENTYPE_H__
#define __MC_OPENTYPE_H__

#include <gtk/gtk.h>

GtkWidget *mc_opentype_config_widget_new(void);

void mc_update_opentype(void);

#endif
