/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __MC_TABSIZE_H__
#define __MC_TABSIZE_H__

#include <gtk/gtk.h>

GtkWidget *mc_tabsize_config_widget_new(void);

void mc_update_tabsize(void);

#endif
