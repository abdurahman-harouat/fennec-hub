/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __MC_UNICODE_AREAS_H__
#define __MC_UNICODE_AREAS_H__

char *mc_get_unicode_areas(char *areas);

#endif
