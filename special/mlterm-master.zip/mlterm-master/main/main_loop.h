/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __MAIN_LOOP_H__
#define __MAIN_LOOP_H__

int main_loop_init(int argc, char **argv);

void main_loop_final(void);

int main_loop_start(void);

#endif
