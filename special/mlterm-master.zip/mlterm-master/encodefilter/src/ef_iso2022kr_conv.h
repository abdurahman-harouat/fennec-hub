/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __EF_ISO2022KR_CONV_H__
#define __EF_ISO2022KR_CONV_H__

#include "ef_conv.h"

ef_conv_t *ef_iso2022kr_conv_new(void);

#endif
