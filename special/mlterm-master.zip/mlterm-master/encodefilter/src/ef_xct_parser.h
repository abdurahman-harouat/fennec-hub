/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __EF_XCT_PARSER_H__
#define __EF_XCT_PARSER_H__

#include "ef_conv.h"

ef_parser_t *ef_xct_parser_new(void);

#endif
