/* -*- c-basic-offset:2; tab-width:2; indent-tabs-mode:nil -*- */

#ifndef __EF_SJIS_CONV_H__
#define __EF_SJIS_CONV_H__

#include "ef_conv.h"

ef_conv_t *ef_sjis_conv_new(void);

ef_conv_t *ef_sjisx0213_conv_new(void);

#endif
